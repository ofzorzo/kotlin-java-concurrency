import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Philosopher implements Runnable{
    
    private Object leftForkLock;
    private Object rightForkLock;
    private final int SLEEP_MULTIPLIER = 100;
    public static final String outFileName = "eaters_report.txt";
    public static final int TIME_TO_RUN = 120; // time for each philosopher to run in seconds
    
    
    public Philosopher(Object leftLock, Object rightLock){
        this.leftForkLock = leftLock;
        this.rightForkLock = rightLock;
    }

    
    private void eat() throws InterruptedException, IOException{
        //System.out.println(Thread.currentThread().getName() + " eating ... ");
        BufferedWriter writer = new BufferedWriter(new FileWriter(this.outFileName, true));
        writer.write(Thread.currentThread().getName().replace("Philosopher ", ""));
        writer.newLine();
        writer.close();
        //Thread.sleep((long) (SLEEP_MULTIPLIER * Math.random()));
    }
    
    @Override
    public void run() {
        long beg = System.currentTimeMillis();
        long end = beg;
        while ((end - beg) / 1000 <= TIME_TO_RUN) {
           try {
               //thinking
               
               synchronized (this.leftForkLock){
                   synchronized(this.rightForkLock){
                       this.eat();
                   }
               }
           } catch (InterruptedException ex) {
              Thread.currentThread().interrupt();
              return;
           } catch (IOException ex) {
              Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
           }
           end = System.currentTimeMillis();
       }
    }

    

    
}
